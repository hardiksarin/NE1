package com.example.ne.util;


public class Keys {

    public static final String KEY_CONTACTS = "Sheet1";
    public static final String KEY_NAME = "name";
    public static final String KEY_COUNTRY = "country";

}